package com.example.helloworld;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class FirestoreActivity extends AppCompatActivity {

    private static final String TAG = "FirestoreActivity";

    private FirebaseFirestore db;

    private EditText ed_date;

    private EditText ed_content;

    private Button btn_upload;

    private Button btn_show;

    private Button btn_back;


    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_firestore);

        //initialise UI
        iniUI();

        //back to menu
        backToMenu();

        //show data
        showData();

        //upload data
        uploadData();

    }

    private void iniUI() {

        //create the instance of database
        db = FirebaseFirestore.getInstance();

        ed_date = (EditText) findViewById(R.id.ed_date);

        ed_content = (EditText) findViewById(R.id.ed_content);

        btn_upload = (Button)findViewById(R.id.btn_upload);

        btn_show = (Button)findViewById(R.id.btn_show);

        btn_back = (Button)findViewById(R.id.btn_back);

    }

    private void backToMenu()
    {
        btn_back.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                finish();

            }

        });
    }

    private void uploadData()
    {
        btn_upload.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // Create a new user with a first and last name
                Map<String, Object> user = new HashMap<>();

                user.put("date", ed_date.getText().toString());

                user.put("content", ed_content.getText().toString());

                // Add a new document with a generated ID
                db.collection("posts")

                        .add(user)

                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {

                                Log.d(TAG,"DocumentSnapshot added with ID: " + documentReference.getId());

                            }
                        })

                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                                Log.w(TAG, "Error adding document", e);

                            }
                        });
            }

        });
    }

    private void showData() {

        btn_show.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                db.collection("posts")

                        .get()

                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {

                            @Override

                            public void onComplete(@NonNull Task<QuerySnapshot> task) {

                                if (task.isSuccessful()) {

                                    for (QueryDocumentSnapshot document : task.getResult()) {

                                        Log.d(TAG, document.getId() + " => " + document.getData());

                                    }
                                } else {

                                    Log.w(TAG, "Error getting documents.", task.getException());

                                }
                            }
                        });
            }
        });
    }

}
