package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;

import android.os.Bundle;

import android.view.View;

import android.view.View.OnClickListener;

import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btn_realtime;

    private Button btn_firestore;

    private Button btn_combine;

    @Override

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);


        btn_realtime = (Button)this.findViewById(R.id.btn_realtime);

        btn_realtime.setOnClickListener(new OnClickListener() {

            @Override

            public void onClick(View v) {

                Intent intent = new Intent();

                // from MainActivity to RealTimeActivity
                intent.setClass(MainActivity.this, RealTimeActivity.class);

                // set parameter
                //intent.putExtra("name", "Wilson");

                startActivity(intent);

            }

        });


        btn_firestore = (Button)this.findViewById(R.id.btn_firestore);

        btn_firestore.setOnClickListener(new OnClickListener() {

            @Override

            public void onClick(View v) {

                Intent intent = new Intent();

                // from MainActivity to RealTimeActivity
                intent.setClass(MainActivity.this, FirestoreActivity.class);

                // set parameter
                //intent.putExtra("name", "Wilson");

                startActivity(intent);

            }

        });


        btn_combine = (Button)this.findViewById(R.id.btn_combine);

        btn_combine.setOnClickListener(new OnClickListener() {

            @Override

            public void onClick(View v) {

                Intent intent = new Intent();

                // from MainActivity to RealTimeActivity
                intent.setClass(MainActivity.this, CombineActivity.class);

                // set parameter
                //intent.putExtra("name", "Wilson");

                startActivity(intent);

            }

        });

    }
}







