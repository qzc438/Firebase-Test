package com.example.helloworld;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class CombineActivity extends AppCompatActivity {

    private static final String TAG = "CombineActivity";

    private DatabaseReference mReference;

    private FirebaseFirestore db;

    private EditText ed_date;

    private EditText ed_content;

    private Button btn_upload_realtime;

    private Button btn_upload_firestore;

    private Button btn_back;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_combine);

        //initialise UI
        iniUI();

        //back to menu;
        backToMenu();

        //upload to Realtime Database
        uploadToRealtime();

        //upload to Cloud Firestore
        uploadToFirestore();

    }

    private void iniUI() {

        //create the instance of Realtime Database
        mReference = FirebaseDatabase.getInstance().getReference();

        //create the instance of Cloud Firestore
        db = FirebaseFirestore.getInstance();

        ed_date = (EditText) findViewById(R.id.ed_date);

        ed_content = (EditText) findViewById(R.id.ed_content);

        btn_upload_realtime = (Button)findViewById(R.id.btn_upload_realtime);

        btn_upload_firestore = (Button)findViewById(R.id.btn_upload_firestore);

        btn_back = (Button)findViewById(R.id.btn_back);

    }

    private void backToMenu()
    {
        btn_back.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                finish();

            }

        });
    }

    private void uploadToRealtime()
    {
        btn_upload_realtime.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                Post post =new Post(ed_date.getText().toString(),ed_content.getText().toString());

                mReference.child("posts").push().setValue(post);

                showSuccessToRealtimeDialog();
            }

        });

    }

    private void showSuccessToRealtimeDialog()
    {
        new AlertDialog.Builder(this)

                .setTitle("Message")

                .setMessage("Add to Realtime Database successfully.")

                .setPositiveButton("OK", null)

                .show();
    }

    private void uploadToFirestore()
    {
        btn_upload_firestore.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                Map<String, Object> post = new HashMap<>();

                post.put("date", ed_date.getText().toString());

                post.put("content", ed_content.getText().toString());

                // Add a new document with a generated ID
                db.collection("posts")

                        .add(post)

                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {

                                Log.d(TAG,"DocumentSnapshot added with ID: " + documentReference.getId());

                                showSuccessToFirestoreDialog();

                            }
                        })

                        .addOnFailureListener(new OnFailureListener() {

                            @Override

                            public void onFailure(@NonNull Exception e) {

                                Log.w(TAG, "Error adding document", e);

                            }
                        });
            }

        });
    }

    private void showSuccessToFirestoreDialog()
    {
        new AlertDialog.Builder(this)

                .setTitle("Message")

                .setMessage("Add to Cloud Firestore successfully.")

                .setPositiveButton("OK", null)

                .show();
    }

}
