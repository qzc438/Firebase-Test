package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.util.Log;

import android.view.View;

import android.widget.Button;

import android.widget.EditText;

import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;

import com.google.firebase.database.DatabaseError;

import com.google.firebase.database.DatabaseReference;

import com.google.firebase.database.FirebaseDatabase;

import com.google.firebase.database.ValueEventListener;


public class RealTimeActivity extends AppCompatActivity {

    private static final String TAG = "RealTimeActivity";

    private DatabaseReference mReference;

    private EditText ed_date;

    private EditText ed_content;

    private Button btn_upload;

    private Button btn_back;

    private TextView tv_date;

    private TextView tv_content;


    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_realtime);

        //initialise UI
        iniUI();

        //back to menu
        backToMenu();

        //show data
        showData();

        //upload data
        uploadData();

    }

    private void iniUI() {

        //create the instance of database
        mReference = FirebaseDatabase.getInstance().getReference();

        ed_date = (EditText) findViewById(R.id.ed_date);

        ed_content = (EditText) findViewById(R.id.ed_content);

        btn_upload = (Button)findViewById(R.id.btn_upload);

        btn_back = (Button)findViewById(R.id.btn_back);

        tv_date = (TextView) findViewById(R.id.tv_date);

        tv_content = (TextView) findViewById(R.id.tv_content);

    }

    private void backToMenu()
    {
        btn_back.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {
                finish();
            }

        });
    }

    private void showData() {

        //find node by key

        DatabaseReference date = mReference.child("date");

        DatabaseReference content = mReference.child("content");

        // register date listener

        date.addValueEventListener(new ValueEventListener() {

            @Override

            public void onDataChange(DataSnapshot dataSnapshot) {

                //invoke this method when date changed

                String value = dataSnapshot.getValue(String.class);

                tv_date.setText("date in Firebase：" + value);

                Log.d(TAG, "date is: " + value);
            }

            @Override

            public void onCancelled(DatabaseError databaseError) {

                Log.w(TAG, "Failed to read value.", databaseError.toException());
            }

        });

        //register content listener

        content.addValueEventListener(new ValueEventListener() {

            @Override

            public void onDataChange(DataSnapshot dataSnapshot) {

                //invoke this method when date changed

                String value = dataSnapshot.getValue(String.class);

                tv_content.setText("content in Firebase：" + value);

                Log.d(TAG, "content is: " + value);
            }

            @Override

            public void onCancelled(DatabaseError databaseError) {

                Log.w(TAG, "Failed to read value.", databaseError.toException());

            }

        });

    }

    private void uploadData()
    {
        btn_upload.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                mReference.child("date").setValue(ed_date.getText().toString());

                mReference.child("content").setValue(ed_content.getText().toString());

            }

        });

    }

}
